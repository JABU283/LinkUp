# LinkUp — starter prototype

This is a mobile-friendly front-end prototype for LinkUp, a blue-and-white social app concept for South Africans.

## Run it
1. Extract the ZIP.
2. Open `index.html` in a modern browser (Chrome recommended).
3. On Android, you can open the file from your Downloads folder. For easier ongoing use, upload the files to a static host.

## Working in this prototype
- Responsive home feed and mobile navigation
- Sample stories/status
- Create text posts and choose decorative demo image styles
- Like posts, comment counters, and share action
- Sample chats and locally interactive message bubbles
- Groups, profile, and notifications screens
- Posts persist in this browser using localStorage

## Important limitations
This is a front-end demo, not a live social network. Posts and chat messages are stored only in the browser/device. Other people cannot see them. Login, real accounts, cloud database, real photo/video uploads, push notifications, encryption, real-time chat, and voice/video calls still need a backend and production security work. Do not enter real passwords or sensitive information into this demo.

## Suggested next stage
Connect authentication and database services, then build real user accounts, cloud posts/media, and real-time private messaging before inviting public users.
